export default function Step2({ formData, handleChange, onNext, onPrev, errors }) {
  const isFormValid = 
    formData.rua && 
    formData.cep && 
    formData.cidade && 
    formData.estado;

  return (
    <div>
      <h2>Cadastro - Etapa 2: Endereço</h2>
      
      <input
        type="text"
        placeholder="Rua"
        name="rua"
        value={formData.rua}
        onChange={handleChange}
      />
      {errors.rua && <p style={{color: "red"}}>{errors.rua}</p>}
      
      <input
        type="text"
        placeholder="CEP"
        name="cep"
        value={formData.cep}
        onChange={handleChange}
      />
      {errors.cep && <p style={{color: "red"}}>{errors.cep}</p>}
      
      <input
        type="text"
        placeholder="Cidade"
        name="cidade"
        value={formData.cidade}
        onChange={handleChange}
      />
      {errors.cidade && <p style={{color: "red"}}>{errors.cidade}</p>}
      
      <input
        type="text"
        placeholder="Estado (UF)"
        name="estado"
        value={formData.estado}
        onChange={handleChange}
      />
      {errors.estado && <p style={{color: "red"}}>{errors.estado}</p>}
      
      <button onClick={onPrev}>Voltar</button>
      <button onClick={onNext} disabled={!isFormValid}>Próximo</button>
    </div>
  );
}