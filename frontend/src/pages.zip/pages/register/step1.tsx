export default function Step1({ formData, handleChange, nextStep, errors }) {
  const isFormValid = 
    formData.name && 
    formData.email && 
    formData.password && 
    formData.data_nascimento && 
    (formData.password === formData.confirmPassword);

  return (
    <div>
      <h2>Cadastro - Etapa 1: Dados do Usuário</h2>
      
      <input
        type="text"
        placeholder="Nome"
        name="name"
        value={formData.name}
        onChange={handleChange}
      />
      {errors.name && <p style={{color: "red"}}>{errors.name}</p>}
      
      <input
        type="email"
        placeholder="Email"
        name="email"
        value={formData.email}
        onChange={handleChange}
      />
      {errors.email && <p style={{color: "red"}}>{errors.email}</p>}
      
      <input
        type="password"
        placeholder="Senha"
        name="password"
        value={formData.password}
        onChange={handleChange}
      />
      {errors.password && <p style={{color: "red"}}>{errors.password}</p>}
      
      <input
        type="password"
        placeholder="Confirmação de Senha"
        name="confirmPassword"
        value={formData.confirmPassword}
        onChange={handleChange}
      />
      {errors.confirmPassword && <p style={{color: "red"}}>{errors.confirmPassword}</p>}
      
      <input
        type="date"
        name="data_nascimento"
        value={formData.data_nascimento}
        onChange={handleChange}
      />
      
      <label>
        <input
          type="checkbox"
          name="status_email"
          checked={formData.status_email}
          onChange={handleChange}
        /> 
        Aceita receber emails?
      </label>
      
      <button onClick={nextStep} disabled={!isFormValid}>Próximo</button>
    </div>
  );
}