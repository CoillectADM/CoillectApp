export default function Step3({ formData, handleChange, onPrev, onSubmit }) {
  const isFormValid = formData.telefone;

  return (
    <div>
      <h2>Cadastro - Etapa 3: Telefone</h2>
      
      <input
        type="text"
        placeholder="Telefone"
        name="telefone"
        value={formData.telefone}
        onChange={handleChange}
      />
      
      <button onClick={onPrev}>Voltar</button>
      <button onClick={onSubmit} disabled={!isFormValid}>Cadastrar</button>
    </div>
  );
}