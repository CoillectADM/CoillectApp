import { useState } from 'react';
import Step1 from './step1';
import Step2 from './Step2';
import Step3 from './step3';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function RegisterPage() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    data_nascimento: '',
    status_email: true,
    rua: '',
    cep: '',
    cidade: '',
    estado: '',
    telefone: '',
  });
  const [userId, setUserId] = useState(null); // Armazena o ID do usuário criado na etapa 1
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  // Função para converter a data de nascimento para o formato DD/MM/YYYY
  const formatDate = (date) => {
    const [year, month, day] = date.split('-'); // Formato YYYY-MM-DD
    return `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${year}`; // Retorna DD/MM/YYYY
  };

  const nextStep = async () => {
    try {
      if (step === 1) {
        if (!validateStep1()) return;

        // Formatar a data de nascimento para DD/MM/YYYY
        const formattedDate = formatDate(formData.data_nascimento);

        // Envia apenas os dados da etapa 1
        const userRes = await axios.post('http://localhost:3201/api/user', {
          name: formData.name,
          email: formData.email,
          password: formData.password,
          data_nascimento: formattedDate, // Enviar a data formatada corretamente
          status_email: formData.status_email,
        });

        setUserId(userRes.data.data.id); // Guarda o ID para as próximas etapas
        setStep(2);
      
      } else if (step === 2) {
        if (!validateStep2()) return;

        // Envia apenas os dados da etapa 2 com o userId
        await axios.post(`http://localhost:3201/api/user/address/${userId}`, {
          rua: formData.rua,
          cep: formData.cep,
          cidade: formData.cidade,
          estado: formData.estado,
        });

        setStep(3);
      }
    } catch (err) {
      console.error(err);
      alert('Erro ao cadastrar. Verifique os dados.');
    }
  };

  const prevStep = () => {
    setStep((prev) => prev - 1);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const validateStep1 = () => {
    const newErrors = {};
    if (!formData.name) newErrors.name = "Nome é obrigatório";
    if (!formData.email) newErrors.email = "Email é obrigatório";
    if (!formData.password) newErrors.password = "Senha é obrigatória";
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "As senhas não coincidem";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors = {};
    if (!formData.rua) newErrors.rua = "Rua é obrigatória";
    if (!formData.cep) newErrors.cep = "CEP é obrigatório";
    if (!formData.cidade) newErrors.cidade = "Cidade é obrigatória";
    if (!formData.estado) newErrors.estado = "Estado é obrigatório";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Envia apenas os dados da etapa 3 com o userId
      await axios.post(`http://localhost:3201/api/user/phone_number/${userId}`, {
        telefone: formData.telefone,
      });

      alert('Cadastro realizado com sucesso!');
      navigate('/login');
    } catch (err) {
      console.error(err);
      alert('Erro ao cadastrar telefone. Verifique os dados.');
    }
  };

  return (
    <div className="register-container">
      <h2>Cadastro</h2>
      {step === 1 && (
        <Step1 
          formData={formData} 
          handleChange={handleChange} 
          nextStep={nextStep} 
          errors={errors} 
        />
      )}
      {step === 2 && (
        <Step2 
          formData={formData} 
          handleChange={handleChange} 
          onNext={nextStep} 
          onPrev={prevStep} 
          errors={errors} 
        />
      )}
      {step === 3 && (
        <Step3 
          formData={formData} 
          handleChange={handleChange} 
          onPrev={prevStep} 
          onSubmit={handleSubmit} 
        />
      )}
    </div>
  );
}
