import { UserAddress } from './user_address';

describe('UserAddress', () => {
  it('should be defined', () => {
    expect(new UserAddress()).toBeDefined();
  });
});
