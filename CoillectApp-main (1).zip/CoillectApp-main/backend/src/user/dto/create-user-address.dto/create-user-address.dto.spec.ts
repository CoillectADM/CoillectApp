import { CreateUserAddressDto } from './create-user-address.dto';

describe('CreateUserAddressDto', () => {
  it('should be defined', () => {
    expect(new CreateUserAddressDto()).toBeDefined();
  });
});
