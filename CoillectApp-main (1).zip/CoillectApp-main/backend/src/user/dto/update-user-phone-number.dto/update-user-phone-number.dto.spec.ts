import { UpdateUserPhoneNumberDto } from './update-user-phone-number.dto';

describe('UpdateUserPhoneNumberDto', () => {
  it('should be defined', () => {
    expect(new UpdateUserPhoneNumberDto()).toBeDefined();
  });
});
