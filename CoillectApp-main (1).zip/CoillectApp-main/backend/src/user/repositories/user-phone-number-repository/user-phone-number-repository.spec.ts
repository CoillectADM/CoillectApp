import { UserPhoneNumberRepository } from './user-phone-number-repository';

describe('UserPhoneNumberRepository', () => {
  it('should be defined', () => {
    expect(new UserPhoneNumberRepository()).toBeDefined();
  });
});
