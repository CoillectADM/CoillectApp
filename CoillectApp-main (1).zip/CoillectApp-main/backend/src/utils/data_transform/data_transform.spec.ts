import { DataTransform } from './data_transform';

describe('DataTransform', () => {
  it('should be defined', () => {
    expect(new DataTransform()).toBeDefined();
  });
});
