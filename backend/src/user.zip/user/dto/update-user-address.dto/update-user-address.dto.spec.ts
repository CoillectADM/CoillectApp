import { UpdateUserAddressDto } from './update-user-address.dto';

describe('UpdateUserAddressDto', () => {
  it('should be defined', () => {
    expect(new UpdateUserAddressDto()).toBeDefined();
  });
});
