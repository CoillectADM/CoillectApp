import { CreateUserPhoneNumberDto } from './create-user-phone-number.dto';

describe('CreateUserPhoneNumberDto', () => {
  it('should be defined', () => {
    expect(new CreateUserPhoneNumberDto()).toBeDefined();
  });
});
