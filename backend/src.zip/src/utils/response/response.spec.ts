import { APIResponse } from './response';

describe('APIResponse', () => {
  it('should be defined', () => {
    expect(new APIResponse()).toBeDefined();
  });
});
