import { UserPhoneNumber } from './user_phone_number';

describe('UserPhoneNumber', () => {
  it('should be defined', () => {
    expect(new UserPhoneNumber()).toBeDefined();
  });
});
